function performGetRequest1() { 
    var resultElement = document.getElementById ('product_list'); 
    resultElement.innerHTML = ''; 
    
    axios.get ('http://localhost:8000/api/products', { 
          }) 
    .then (function (response) { 
      console.log (response); 
      resultElement.innerHTML = generateSuccessHTMLOutput (response ); 
    }) 
    .catch (function (error) { 
        resultElement.innerHTML = generateErrorHTMLOutput (error); 
    }); 
  }